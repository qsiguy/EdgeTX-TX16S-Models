Specials widget for EdgeTX
===========================

A simple widget that offers 4 touch buttons. Each button enables/disables a sticky switch (logical switch that has set "stcky" as function)

Note: this widget currently might not be for everyone as you need to adapt it manually for your own labels (see below).

Installation & configuration
============================
1) Copy all contents of this folder to your transmitters SD card to WIDGETS/Specials
2) Adapt the script "loadable.lua" for your own button labels and sticky switches
3) Create the appropriate logic switches