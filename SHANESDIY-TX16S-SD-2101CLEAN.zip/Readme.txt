SHANESDIY-TX16S-SD-2101CLEAN.zip

Properly organized folders containing the following:

*EdgeTX 2.10.1 firmware file

*Multi Module AETR 1.3.4.0 firmware file

*My favorite Widgets

*My sound .wav files

*DSM Forward Programming scripts v0.57

*DSM Smart RX Tel v1.2 (includes Spektrum Avian ESC programmer)

*A few basic model images