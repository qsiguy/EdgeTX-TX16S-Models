SHANESDIY-TX16S-SD-2103CLEAN.zip

Properly organized folders containing the following:

*EdgeTX 2.10.3 firmware file

*Multi Module AETR 1.3.4.0 firmware file

*My favorite Widgets

*My sound .wav files

*DSM Forward Programming scripts v0.58

*DSM Smart RX Tel v1.2 (includes Spektrum Avian ESC programmer)

*A few basic model images