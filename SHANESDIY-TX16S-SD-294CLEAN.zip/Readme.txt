SHANESDIY-TX16S-SD-294CLEAN.zip

Properly organized folders containing the following:

*EdgeTX 2.9.4 firmware file

*Multi Module AETR 1.3.3.33 firmware file

*My favorite Widgets

*My sound .wav files

*DSM Forward Programming scripts v0.56

*DSM Smart RX Tel v1.2 (includes Spektrum Avian ESC programmer)

*A few basic model images