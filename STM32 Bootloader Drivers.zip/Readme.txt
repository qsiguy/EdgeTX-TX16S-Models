Place drivers in these folders:
C:\Windows\system32\DRIVERS\winusb.sys
C:\Windows\system32\WdfCoInstaller01009.dll
C:\Windows\system32\WinUSBCoInstaller2.dll